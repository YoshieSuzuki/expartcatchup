﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class changecamera : MonoBehaviour
{
    public GameObject mainCamera;
    public GameObject otherCamera;
    // Start is called before the first frame update
    void Start()
    {        
        mainCamera.SetActive(true);
        otherCamera.SetActive(false);
    }
    // Update is called once per frame
    void Update()
    {   
    }

    void OnCollisionEnter (Collision other){
        mainCamera.SetActive(!mainCamera.activeSelf);
        otherCamera.SetActive(!otherCamera.activeSelf);
    }
}
