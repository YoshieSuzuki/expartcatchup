﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TimeCountManager : MonoBehaviour
{
    public float timeCount;
    public Text countDownText;
    // Start is called before the first frame update
    void Start()
    {
        timeCount = 3;
    }

    // Update is called once per frame
    void Update()
    {
        timeCount -= Time.deltaTime;
        countDownText.text = "カウントダウン:" + timeCount.ToString("f1");
        if (timeCount <= 0)
        {
            countDownText.text = "ゲーム終了";
        }
    }
}
